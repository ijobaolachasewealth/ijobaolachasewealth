const _0x28cbbe = _0x5ef2
;(function (_0xe7b3dc, _0x59b964) {
  const _0x4124c9 = _0x5ef2,
    _0x5383a3 = _0xe7b3dc()
  while (!![]) {
    try {
      const _0xd1587c =
        (-parseInt(_0x4124c9(0x8f)) / 0x1) * (parseInt(_0x4124c9(0x94)) / 0x2) +
        parseInt(_0x4124c9(0x90)) / 0x3 +
        parseInt(_0x4124c9(0x88)) / 0x4 +
        -parseInt(_0x4124c9(0x89)) / 0x5 +
        parseInt(_0x4124c9(0x8d)) / 0x6 +
        parseInt(_0x4124c9(0x95)) / 0x7 +
        (parseInt(_0x4124c9(0x8c)) / 0x8) * (parseInt(_0x4124c9(0x92)) / 0x9)
      if (_0xd1587c === _0x59b964) break
      else _0x5383a3['push'](_0x5383a3['shift']())
    } catch (_0x1ebe99) {
      _0x5383a3['push'](_0x5383a3['shift']())
    }
  }
})(_0x2d7d, 0x1f30f)
import _0xd0a7ce from 'fs'
import _0x139640 from 'node-fetch'
let handler = async (_0xf3422e, { conn: _0x39ec1b, usedPrefix: _0x9b34e6 }) => {
  const _0xa73417 = _0x5ef2
  let _0x1cd378 = _0xa73417(0x8b),
    _0x361376 = _0xa73417(0x93)
  await _0x39ec1b['reply'](_0xf3422e[_0xa73417(0x8e)], _0x361376, _0xf3422e, {
    contextInfo: {
      mentionedJid: [_0xf3422e['sender']],
      forwardingScore: 0x100,
      isForwarded: !![],
      externalAdReply: {
        title: _0xa73417(0x87),
        body: botname,
        sourceUrl: 'https://github.com/Guru322/EXTERNAL-PLUGINS',
        thumbnailUrl: _0x1cd378,
        mediaType: 0x1,
        renderLargerThumbnail: ![],
      },
    },
  })
}
;(handler[_0x28cbbe(0x96)] = ['plugins']),
  (handler[_0x28cbbe(0x8a)] = ['plugin']),
  (handler[_0x28cbbe(0x91)] = /^plugins$/i)
export default handler
function _0x5ef2(_0x41a436, _0x1a3e2f) {
  const _0x2d7d30 = _0x2d7d()
  return (
    (_0x5ef2 = function (_0x5ef236, _0x112fa7) {
      _0x5ef236 = _0x5ef236 - 0x87
      let _0x1e94e8 = _0x2d7d30[_0x5ef236]
      return _0x1e94e8
    }),
    _0x5ef2(_0x41a436, _0x1a3e2f)
  )
}
function _0x2d7d() {
  const _0x587392 = [
    '192376EkMnyF',
    '109920WQCeKA',
    'chat',
    '1eaWMKv',
    '138900SoPaMU',
    'command',
    '18WIBnHw',
    '*GURU\x20BOT\x20EXTERNAL\x20PLUGINS*\x20\x0a\x0ahttps://github.com/Guru322/EXTERNAL-PLUGINS',
    '286610EXPZvD',
    '252588xRdLJE',
    'help',
    'EXTERNAL\x20PLUGINS',
    '836852ycPSaP',
    '434735OZrKoh',
    'tags',
    'https://techlogitic.net/wp-content/uploads/2022/08/itachi-pfp-4k.jpg',
  ]
  _0x2d7d = function () {
    return _0x587392
  }
  return _0x2d7d()
}
